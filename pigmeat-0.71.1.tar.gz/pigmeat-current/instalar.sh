#!/bin/bash
#########################################################
# Checando modulos
#########################################################
#trap "echo -en \"\nNao deixo voce me interromper ! nhe nhe nhe nheeee !\n\"" 1 2 3 4 5 6 7 8 9 # Pra nao deixar vc interromper o programa

VER="0.17" #For PigMeat 0.7x w/ update
echo
echo "Instalador do PigMeat Ver.: $VER"
echo "Versao PigMeat sendo instalada: `cat VERSION`"
echo "------------------------------------"
sleep 1
echo
echo "Testando os modulos necessarios..."
echo
for PM in `echo strict MD5 Carp IO::Socket Net::hostent Digest::MD5 Crypt::PasswdMD5 Term::Complete Term::ReadLine`; do
    echo -n "- Modulo $PM... "
    perl -e "use $PM" 2> /dev/null;
    if [ "$?" -ne "0" ]; then
        echo "Nao encontrado"
        ERROR="yes"
        MMOD="$MMOD $PM"
    else
        echo "OK"
    fi
done
#########################################################
if [ "$ERROR" = "yes" ]; then
    echo -en "\n- Va ate a CPAN e instale os modulos que faltam !\n- perl -MCPAN -e 'shell'\n\n"
    echo -en "\n-------------------------------------------------\nModuloes faltando: $MMOD\n"
    read -n 1 -p "Tentar baixar os modulos ? (ou continuar sem eles) (s/n/c)" YN
    echo
    if [ "$YN" = "s" ]; then
        echo "Checando configuracao da CPAN..."
        ./bin/firstcpan.pl
        echo "Chamando PerlModule Installer by Ramoni (myself)..."
        sleep 2;
    #################################
    #     Qnd o pminstaller soh aceitava um modulo por vez:
    #        for CADA in $MMOD; do
    #            echo -en "\n-------------------------------------------------\nTentando instalar modulo $CADA...\n"
    #            (./pm-installer.sh $CADA)
    #        done
    #################################
        (./bin/pm-installer.sh $MMOD)
        echo -en "\n\n* Agora rode novamente o instalador... ($0)\n\n";
        sleep 1;
    elif [ "$YN" = "n" ]; then
        exit
    fi
fi

echo;echo;echo
echo "---------------------------------------------------"
KNL=`kernelversion`
echo "- Serie do kernel detectada: $KNL"
if [ ! "$KNL" = "2.4" ]; then
    echo "- O Pigmeat vem com regras para iptables, mas basta mudar no arquivo de configuracao"
    echo "- para usar ipchains."
else
    echo "- OK"
fi
sleep 1
echo;echo
echo "---------------------------------------------------"
echo "- Responda as perguntas abaixo:"
echo "- (Respostas em branco implicarao no default -> [])"
echo
#########################################################
function GETDATA()
{
#echo "---------------------------------------------------"
echo "-- Diretorios e Arquivos --"
PIGPATH="/jerks-,-do-not-create-this-directory"
until [ -d $PIGPATH ]; do
    read -p "+ Onde instalar o PigMeat: [/sbin]: " PIGPATH
    if [ -z $PIGPATH ]; then PIGPATH="/sbin"; fi
    if [ ! -d $PIGPATH ]; then echo "$PIGPATH => diretorio nao encontrado !";fi
done
DOCPATH="/jerks-,-do-not-create-this-directory"
until [ -d $DOCPATH ]; do
    read -p "+ Diretorio de documentacao: [/usr/doc/pigmeat]: " DOCPATH
    if [ -z $DOCPATH ]; then DOCPATH="/usr/doc/pigmeat"; fi
    if [ ! -d $DOCPATH ]; then mkdir -p $DOCPATH;fi
done
SNORTLOG="/jerks-,-do-not-create-this-directory"
until [ -f $SNORTLOG ]; do
    read -p "+ Arquivo de log do SNORT: [/var/log/snort/alert]: " SNORTLOG
    if [ -z $SNORTLOG ]; then SNORTLOG="/var/log/snort/alert"; fi
    if [ ! -f $SNORTLOG ]; then echo "$SNORTLOG => Arquivo nao encontrado !";fi
done
FILESPATH="/jerks-,-do-not-create-this-directory"
until [ -d $FILESPATH ]; do
    read -p "+ Diretorio para arquivos de blocked, ignored, log e password: [/var/log/snort]: " FILESPATH
    if [ -z $FILESPATH ]; then FILESPATH="/var/log/snort"; fi
    if [ ! -d $FILESPATH ]; then echo "$FILESPATH => diretorio nao encontrado !";fi
done
BLOCKEDPATH="/jerks-,-do-not-create-this-directory"
until [ -f $FILESPATH/$BLOCKEDPATH ]; do
    read -p "+ Arquivo de blocked hosts: [hosts.blocked]: $FILESPATH/" BLOCKEDPATH
    if [ -z $BLOCKEDPATH ]; then BLOCKEDPATH="hosts.blocked"; fi
    if [ ! -f $FILESPATH/$BLOCKEDPATH ]; then touch $FILESPATH/$BLOCKEDPATH;fi
done
IGNOREDPATH="/jerks-,-do-not-create-this-directory"
until [ -f $FILESPATH/$IGNOREDPATH ]; do
    read -p "+ Arquivo de ignored hosts: [hosts.ignored]: $FILESPATH/" IGNOREDPATH
    if [ -z $IGNOREDPATH ]; then IGNOREDPATH="hosts.ignored"; fi
    if [ ! -f $FILESPATH/$IGNOREDPATH ]; then touch $FILESPATH/$IGNOREDPATH;fi
done


LOGPATH="/jerks-,-do-not-create-this-directory"
until [ -f $FILESPATH/$LOGPATH ]; do
    read -p "+ Arquivo de LOG: [pigmeat.log]: $FILESPATH/" LOGPATH
    if [ -z $LOGPATH ]; then LOGPATH="pigmeat.log"; fi
    if [ ! -f $FILESPATH/$LOGPATH ]; then touch $FILESPATH/$LOGPATH;fi
done



PASSWDPATH="/jerks-,-do-not-create-this-directory"
until [ -f $FILESPATH/$PASSWDPATH ]; do
    read -p "+ Arquivo de senhas p/ acesso remoto: [pigpasswd]: $FILESPATH/" PASSWDPATH
    if [ -z $PASSWDPATH ]; then PASSWDPATH="pigpasswd"; fi
    if [ ! -f $FILESPATH/$PASSWDPATH ]; then touch $FILESPATH/$PASSWDPATH;fi
done



ISF="/jerks-,-do-not-create-this-directory"
until [ -f $FILESPATH/$ISF ]; do
    read -p "+ Lista de assinaturas para ignorar: [signatures]: $FILESPATH/" ISF
    if [ -z $ISF ]; then ISF="signatures"; fi
    if [ ! -f $FILESPATH/$ISF ]; then cp signatures $FILESPATH/$ISF;fi
done


COUNTDIR="/jerks-,-do-not-create-this-directory"
until [ -d $FILESPATH/$COUNTDIR ]; do
    read -p "+ Diretorio de statisticas:[stats]: $FILESPATH/" COUNTDIR
    if [ -z $COUNTDIR ]; then COUNTDIR="stats"; fi
    if [ ! -d $FILESPATH/$COUNTDIR ]; then mkdir -p $FILESPATH/$COUNTDIR;fi
done


echo "---------------------------------------------
Arquivo de log do Snort = $SNORTLOG
Arquivo de hosts ignorados = $FILESPATH/$IGNOREDPATH
Arquivo de hosts bloqueados = $FILESPATH/$BLOCKEDPATH
Arquivo de LOG do PigMeat = $FILESPATH/$LOGPATH
Arquivo de senhas p/ acesso remoto = $FILESPATH/$PASSWDPATH
Lista de assinaturas ignoradas = $FILESPATH/$ISF
Diretorio de statisticas = $FILESPATH/$COUNTDIR
"
}
GETDATA
#########################################################
read -n1 -p "Tudo OK ? (s/n): " YN
while [ "$YN" != "s" -a  "$YN" != "S" -a  "$YN" != "y" -a  "$YN" != "Y" ]; do
    GETDATA
read -n1 -p "Tudo OK ? (s/n): " YN
done
#########################################################
function GETCONF()
{
echo 
echo
echo "-- Configuracoes do PIGMEAT --"
echo "- Configurando /etc/pigmeat.conf..."

while [ -z $METHOD ]; do
echo "---------------------------------------------------"
echo "- Metodo do prompt interativo: "
echo -e "\t1) complete - Completa comandos e IPs com TAB"
echo -e "\t2) history - Grava um historico para acessar com as setas"
read -n 1 -p "  Opcao [1/2]: " MET
case $MET in
    1) METHOD="complete" ;;
    2) METHOD="history" ;;
    *) METHOD="" ;;
esac
done
echo
echo

while [ -z $MN ]; do
echo "---------------------------------------------------"
echo "- Notificacao por email: "
echo -e "\t1) sim - Toda vez que for bloqueado um IP manda um email"
echo -e "\t2) nao - Nao obrigado, isso geraria muito trafego de email :)"
read -n 1 -p "  Opcao [1/2]: " MN
case $MN in
    1) MN="yes" ;;
    2) MN="no" ;;
    *) MN="" ;;
esac
done
echo

if [ "$MN" = "yes" ]; then
while [ -z $MWHO ]; do
read -p "- Destinatario do email: " MWHO
done
else
    MWHO="root@localhost"
fi

MWHO=`echo $MWHO | sed 's/@/\\\@/g'`
while [ -z $PORTA ]; do
read -p "- Porta para acesso remoto [9000]: " PORTA
if [ -z $PORTA ]; then PORTA=9000; fi
done

}
GETCONF

echo "---------------------------------------------
Modo de prompt: $METHOD
Notificacao por email: $MN
Para: $MWHO
Porta para acesso remoto: $PORTA

"

#########################################################
read -n1 -p "Tudo OK ? (s/n): " YN
while [ "$YN" != "s" -a  "$YN" != "S" -a  "$YN" != "y" -a  "$YN" != "Y" ]; do
    GETCONF
read -n1 -p "Tudo OK ? (s/n): " YN
done
#########################################################
echo;echo
echo "----------------------------------------------"
echo "- Configuracao do PigInit (programa pra controlar o pigmeat)"
echo " - Arquivo: /etc/piginit.conf"
echo
read -p "- Console de mensagens e prompt [/dev/tty11]: /dev/tty" PROMPTTTY
    if [ -z $PROMPTTTY ];then PROMPTTTY="11"; fi
echo
read -p "- Console de avisos de blocks e ignores [/dev/tty12]: /dev/tty" ERRORTTY
    if [ -z $ERRORTTY ];then ERRORTTY="12"; fi
echo
read -p "- Opcoes defaults (--server --prompt --color) [--server --color]: " DEFOPTIONS
    if [ -z $DEFOPTIONS ];then DEFOPTIONS="--server --color"; fi
echo
echo

#########################################################
echo
echo "- Escrevendo configuracao do PigInit em /etc/piginit.conf"
cat << PIGINITFIM > /etc/piginit.conf
#!/bin/bash

# Console do prompt e msgs de inicio:
PROMPTTTY="/dev/tty$PROMPTTTY"

# Console pro log do pigmeat, como blocks e ignores:
ERRORTTY="/dev/tty$ERRORTTY"

# Opcoes default caso nenhuma seja fornecida
# (--prompt,--server,--color)
DEFAULT_OPTIONS="$DEFOPTIONS"

PIGINITFIM
sleep 1
echo "- Escrevendo configuracao em: /etc/pigmeat.conf"
cat << PIGCONFFIM > /etc/pigmeat.conf
#!/usr/bin/perl
##############################################
# PigMeat FoR SNORT - Control Tool based on  #
# the SNORT Log File                         #
# COPYRIGHT 2001 Ramoni, GPL                 #
#--------------------------------------------#                                  
# Program by Ramoni <ramoni@databras.com.br> #                                  
##############################################                                  
\$INSTALLPATH="$PIGPATH";
\$DOCPATH="$DOCPATH";
#############################################################################
# Options to set:                                                           #
#                                                                           #
##############################################                              #
# Optional Features:                         #                              #
#--------------------------------------------#                              #
# Select "complete" or "history".            #                              #
# history: add command history support       #                              #
# complete: add command completation support #                              #
\$PROMPTMETHOD="$METHOD";                    #                              #
#--------------------------------------------#                              #
# MAILNOTICE: send mail notification         #                              #
# everytime a block occurs. <yes|no>         #                              #
# MAILTO: who will receive the notification  #                              #
\$MAILNOTICE="$MN";                           #                              #
\$MAILTO="$MWHO";           #                              #
##################################################                          #
# Set these variables to fit your needs          #                          #
\$SNORTLOG="$SNORTLOG";                #                          #
\$BLOCKFILE="$FILESPATH/$BLOCKEDPATH";       #                          #
\$IGNOREFILE="$FILESPATH/$IGNOREDPATH";      #                          #
\$REMOTEPASSWDFILE="$FILESPATH/$PASSWDPATH";    #                          #
\$LOGFILE="$FILESPATH/$LOGPATH";                #                          #
\$IGNOREDSIGNATURESFILE="$FILESPATH/$ISF";
\$TMPFILE="/tmp/iii";                             #                          #
\$COUNTDIR="$FILESPATH/$COUNTDIR";
########################################################                    #
# PIGMEAT RULES                                        #                    #
# These are the commands used to block IPs             #                    #
# You can change it and port to ipchains for example.  #                    #
\$RULEBLOCKINPUT="iptables -I INPUT -j DROP -s " ;      #                    #
\$RULEBLOCKFORWARD="iptables -I FORWARD -j DROP -s " ;  #                    # 
\$RULEDELINPUT="iptables -D INPUT -j DROP -s " ;        #                    #
\$RULEDELFORWARD="iptables -D FORWARD -j DROP -s " ;    #                    #
# The -s in the end is to specify the IP, that is      #                    #
# told by the system call using these variables        #                    #
###################################################################         #
# Server Variables:     # Server can be accessed by telnet        #         #
\$PORT=$PORTA;             # Port PigMeat will open to remote access #         #
#############################################################################
PIGCONFFIM
sleep 1
echo "Checando permissoes..."
chmod 500 /etc/pigmeat.conf
chown root.root /etc/pigmeat.conf
sleep 1

#########################################################
echo
echo "- Copiando pigmeat para $PIGPATH..."; 
    cp -f bin/pigmeat $PIGPATH/pigmeat; 
    chmod 500 $PIGPATH/pigmeat
    chown root.root $PIGPATH/pigmeat
echo "- Copiando piginit para $PIGPATH..."; 
    cp -f bin/piginit $PIGPATH/piginit; 
    chmod 500 $PIGPATH/piginit
    chown root.root $PIGPATH/piginit
echo "- Copiando pigclient para $PIGPATH..."; 
    cp -f bin/pigclient $PIGPATH; 
    chmod 555 $PIGPATH/pigclient
    chown root.root $PIGPATH/pigclient

echo "- Copiando docs para $DOCPATH..."; cp -fR * $DOCPATH
echo "- Criando/checando arquivo $FILESPATH/$BLOCKEDPATH..."
    touch $FILESPATH/$BLOCKEDPATH
    chmod 0600 $FILESPATH/$BLOCKEDPATH
    chown root.root $FILESPATH/$BLOCKEDPATH
echo "- Criando/checando arquivo $FILESPATH/$IGNOREDPATH..."
    touch $FILESPATH/$IGNOREDPATH
    chmod 0600 $FILESPATH/$IGNOREDPATH
    chown root.root $FILESPATH/$IGNOREDPATH
echo "- Criando/checando arquivo $FILESPATH/$LOGPATH..."
    touch $FILESPATH/$LOGPATH
    chmod 0440 $FILESPATH/$LOGPATH
    chown root.root $FILESPATH/$LOGPATH
echo "- Criando/checando arquivo $FILESPATH/$PASSWDPATH..."
    touch $FILESPATH/$PASSWDPATH
    chmod 0000 $FILESPATH/$PASSWDPATH
    chown root.root $FILESPATH/$PASSWDPATH

echo "- Checando arquivo exemplo de assinaturas ignoradas... ($FILESPATH/$ISF)"
    chmod 0000 $FILESPATH/$ISF
    chown root.root $FILESPATH/$ISF

#########################################################
sleep 1
echo
echo "--------------------------------------------------------------------"
echo "- SYSVINIT USERS:"
echo "- Checando se voce usa uma distribuicao baseada em SysVInit..."
if [ -d /etc/rc.d/init.d ]; then
    if [ "`type -p chkconfig`" ]; then
        cp bin/piginit /etc/rc.d/init.d
        chmod 500 $PIGPATH/piginit
        chown root.root $PIGPATH/piginit
        chkconfig --add piginit    
        echo "- PigInit instalado no ntsysv !"
        sleep 1
    else
        echo "- Nao achei o chkconfig para adicionar o piginit no ntsysv."
        echo "- Nao foi instalado o script para iniciar e parar o pigmeat. :("
        sleep 1
    fi
else
    echo "- Voce nao estah usando uma distro baseada em SysVInit nem compativel !"
    echo "- Nao foi instalado o script para iniciar e parar o pigmeat. :("
    sleep 1
fi
echo "--------------------------------------------------------------------"




#########################################################
# Longo e chato comentario:



sleep 1
echo 
echo
echo "Instalaco concluida :)"
sleep 1
echo
echo "- Para mudar as configuracoes, edite o arquivo /etc/pigmeat.conf"
echo "  (procure deixa-lo organizado)"
echo "- Para configurar as regras que serao usadas tambem edite o mesmo arquivo"
echo "- Para informacoes e parametros do pigmeat digite pigmeat --help"
echo "- Bom proveito :)"
sleep 1
echo 
echo "          Ramoni."
echo


